library(reshape2)     
library(ggplot2)
setwd("C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\repeat2\\sc_RNA_edgeR")
all_FC_merge <-  read.csv("all_FC_merge.txt", header=T, sep = "\t",row.names=1)
for(i in 1:length(all_FC_merge$gene)){
  gene <-all_FC_merge$gene[[i]]
  test <- all_FC_merge[all_FC_merge$gene%in%gene,c(2,3,4,5,6)] ##get names of test pairs
  aql <- melt(test)
  aql$gene <- gene
  gene_name<- paste(gene)
  p<-ggplot(aql,aes(variable,value,group =gene )) +geom_point()+geom_line()+xlab(gene_name)+ylab("logFC")+theme_bw() 
  plot_name <- paste(gene,"_logFC.pdf",sep = "")
  ggsave(p,filename = plot_name,width = 8,height = 5) 
}
 