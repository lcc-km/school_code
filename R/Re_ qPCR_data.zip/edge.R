
##################################################
#################edgeR:find DEG##################
###################################################
setwd("C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\repeat2\\sc_RNA_edgeR")
library(edgeR)

spe <- "cochlear"   ## Set the content of the comparison

data <-  read.csv("all_merge.txt", header=T, sep = "\t",row.names=1)

###Set up the group

targets <- data.frame(seq=c(1:13),
                      control=c("E14","E16","E16","E16","P1","P1","P1","P1","P7","P7","P12","P12","P33"),
                      Label=c("E14","E16_1","E16_2","E16_3","P1_1","P1_2","P1_3","P1_4","P7_1","P7_2","P12_1","P12_2","P33"))  


############calculate Differential expression genes  ##########################

###  normalize by TMM and save data to exp_study

y = DGEList(counts=data, group=targets$control)          

y = calcNormFactors(y,method = "TMM") #get TMM normalization factor 
y$samples
y
colnames(y) <- targets$Label   
dim(y)

###  PCA analysis , Evaluate the similarity between the overall expression patterns of the samples

pp<-plotMDS(y,method="bcv")

###  estimating the dispersion  or  Estimating dispersion
y1 <- y #get data
BVC=0.1 ##?????
y1$common.dispersion=BVC
y1 = estimateTagwiseDisp(y1)  #计算普通的离散度
y1 
plotBCV(y1)

############ partly compare###############
t <- list()
conditions <- factor(unique(targets$control))
conditions
for(i in 1:length(conditions)){
  t[[i]] <- c(as.character(conditions[i]),as.character(conditions[1]))
}




thrd <- 0.05
for(i in 1:length(t)){
  ###  get paires
  test <- t[[i]] ##get names of test pairs
  comp <- paste(test[2],test[1],sep = "-")   ## test[2]-test[1]
  comp
  
  ###   exactTest & write file
  et0 <- exactTest(y1,pair = test)
  topTags(et0)
  et0.d <-data.frame(topTags(et0,n=nrow(et0$table)))
  filename1 <- paste(spe,comp,"_all_exact_FC.txt",sep ="")
  write.table(et0.d,filename1,quote=F,sep = "\t")
  
chg_rd=1
  # drawing DE gene plot (optional)
  de <- decideTestsDGE(et0,p=thrd,lfc = chg_rd)###lfc：numeric, minimum absolute log2-fold-change required
  summary(de) ##get number of different exp gene, -1 down regulate#,1 up regulate, 0 no difference
  plotSmear(et0,de.tags = rownames(y1)[as.logical(de)])
  abline(h=c(0-chg_rd,chg_rd),col="blue")
  
  filename <- paste(spe,comp,"_exact_FC",chg_rd,"_FDR",thrd,".pdf",sep ="")
  pdf(file = filename,width = 5,height = 5,title = comp)
  plotSmear(et0,de.tags = rownames(y1)[as.logical(de)])
  abline(h=c(0-chg_rd,chg_rd),col="blue")
  title(paste(spe,comp))
  dev.off()
  
  
  #get DE gene text file
  data0 <- et0.d[abs(et0.d[,"logFC"])>chg_rd & et0.d[,"FDR"]<thrd,]########???logFC>1 FC>2
  filename <- paste(spe,comp,"_exact_FC",chg_rd,"_FDR",thrd,".txt",sep ="")
  write.table(data0,filename,quote=F,sep = "\t")
  
}

#########compare with E14 ##############
library(venn)
library(dplyr)

######### extract gene name to last col 
FC_E14_E16 <- read.csv("cochlearE14-E16_exact_FC1_FDR0.05.txt",sep = "\t")
FC_E14_E16$gene <- row.names(FC_E14_E16)

FC_E14_P1 <- read.csv("cochlearE14-P1_exact_FC1_FDR0.05.txt",sep = "\t")
FC_E14_P1$gene <- row.names(FC_E14_P1)

FC_E14_P7 <- read.csv("cochlearE14-P7_exact_FC1_FDR0.05.txt",sep = "\t")
FC_E14_P7$gene <- row.names(FC_E14_P7)

FC_E14_P12 <- read.csv("cochlearE14-P12_exact_FC1_FDR0.05.txt",sep = "\t")
FC_E14_P12$gene <- row.names(FC_E14_P12)

FC_E14_P33 <- read.csv("cochlearE14-P33_exact_FC1_FDR0.05.txt",sep = "\t")
FC_E14_P33$gene <- row.names(FC_E14_P33)

data_venn <- list(E16=FC_E14_E16$gene,
                  P1=FC_E14_P1$gene,
                  P7=FC_E14_P7$gene,
                  P12=FC_E14_P12$gene,
                  P33=FC_E14_P33$gene)

venn(data_venn,zcolor='style')

#########extract intersect genes of different times

venn_list <- Reduce(intersect,data_venn)

########## show logFC and gene name of intersect genes in different times which compared with E14
FC_E14_E16_venn <- FC_E14_E16[FC_E14_E16$gene%in%venn_list,c(1,5)]
FC_E14_P1_venn <- FC_E14_P1[FC_E14_P1$gene%in%venn_list,c(1,5)]
FC_E14_P7_venn <- FC_E14_P7[FC_E14_P7$gene%in%venn_list,c(1,5)]
FC_E14_P12_venn <- FC_E14_P12[FC_E14_P12$gene%in%venn_list,c(1,5)]
FC_E14_P33_venn <- FC_E14_P33[FC_E14_P33$gene%in%venn_list,c(1,5)]

########## merge logfc at different times in one table
merge11<-merge(FC_E14_E16_venn,FC_E14_P1_venn,by = "gene",all = T)
colnames(merge11)<-c("gene","E14_E16","E14_P1")

merge22<-merge(merge11,FC_E14_P7_venn,by = "gene",all = T)
colnames(merge22)<-c("gene","E14_E16","E14_P1","E14_P7")

merge33<-merge(merge22,FC_E14_P12_venn,by = "gene",all = T)
colnames(merge33)<-c("gene","E14_E16","E14_P1","E14_P7","E14_P12")


all_FC_merge<-merge(merge33,FC_E14_P33_venn,by = "gene",all = T)
colnames(all_FC_merge)<-c("gene","E14_E16","E14_P1","E14_P7","E14_P12","E14_P33")

write.table(all_FC_merge,"all_FC_merge",quote=F,sep = "\t")



