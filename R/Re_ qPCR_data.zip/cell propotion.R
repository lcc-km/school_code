library(Seurat)
library(ggplot2)
library(ggsci)

##################E14####################
setwd("C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\repeat2\\E14 repeat")
E14<-readRDS('E14_2')

new.cluster.ids_3 <- c("KO","IdC","KO","PsC","LER","OC90_Sparcl1","KO","KO","OC90_Otoa",
                       "KO","KO","HC","OC90_Sparcl1")
names(new.cluster.ids_3) <- levels(E14)
E14 <- RenameIdents(E14, new.cluster.ids_3)


DimPlot(E14, reduction = "umap", label = TRUE, pt.size = 0.5,label.size = 6) + NoLegend()
VlnPlot(E14, features = c("Camk2n1","Chst2","Cxcl14","Gm10638","Hmga2","Kctd8","Lrrc10b","Paqr9","Pou4f3","S100a1","S100a13","Syt1","Xist"), 
        pt.size = 0, ncol =5, assay = "RNA",slot = "counts",log = T)+NoLegend()
FeaturePlot(E14, features = c("Camk2n1","Chst2","Cxcl14","Gm10638","Hmga2","Kctd8","Lrrc10b","Paqr9","Pou4f3","S100a1","S100a13","Syt1","Xist"),
            pt.size =  0.05, ncol = 5)
table(Idents(E14))###Count the number of cells in each cluster
prop.table(table(Idents(E14)))###Calculating Cell Proportion
cell.prop_E14<-as.data.frame(prop.table(table(Idents(E14))))
#cell.prop_E14<-as.data.frame(table(Idents(E14)))
colnames(cell.prop_E14)<-c("cell_type","proportion")
cell.prop_E14$time<-"E_14"
signif(cell.prop_E14$proportion, 4)######Keep four decimals
ggplot(cell.prop_E14,aes(cell_type,proportion,fill=cell_type))+geom_bar(stat="identity",position = position_dodge(1))+
    ggtitle("")+theme_bw()+theme(axis.ticks.length=unit(0.5,'cm'))+scale_fill_d3()+
  geom_text(aes(label=signif(proportion, 4), y=proportion+0.02), position=position_dodge(1), vjust=0)+xlab("E14")










##################E16####################
setwd("C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\repeat2\\E16 repeat")
E16<-readRDS('E16_cca')


new.cluster.ids_3 <- c("KO","ISC","L.KO","PsC","unknown","IdC","LER",
                       "HC","OC90","Ube2c+","unknown","Ube2c+","unknown","IPhC",
                       "unknown","Hensen","IPC","unknown",
                       "CC_OSC","CC_OSC")
names(new.cluster.ids_3) <- levels(E16)
E16 <- RenameIdents(E16, new.cluster.ids_3)

DimPlot(E16, reduction = "umap", label = TRUE, pt.size = 0.5,label.size = 6) + NoLegend()
VlnPlot(E16, features = c("Camk2n1","Chst2","Cxcl14","Gm10638","Hmga2","Kctd8","Lrrc10b","Paqr9","Pou4f3","S100a1","S100a13","Syt1","Xist"), 
        pt.size = 0, ncol =5, assay = "RNA",slot = "counts",log = T)+NoLegend()
FeaturePlot(E16, features = c("Camk2n1","Chst2","Cxcl14","Gm10638","Hmga2","Kctd8","Lrrc10b","Paqr9","Pou4f3","S100a1","S100a13","Syt1","Xist"),
            pt.size =  0.05, ncol = 5)

#
table(Idents(E16))
prop.table(table(Idents(E16)))
cell.prop_E16<-as.data.frame(prop.table(table(Idents(E16))))
#cell.prop_E16<-as.data.frame(table(Idents(E16)))
colnames(cell.prop_E16)<-c("cell_type","proportion")
cell.prop_E16$time<-"E_16"
signif(cell.prop_E16$proportion, 4)

#
ggplot(cell.prop_E16,aes(cell_type,proportion,fill=cell_type))+geom_bar(stat="identity",position = position_dodge(1))+
  ggtitle("")+theme_bw()+theme(axis.ticks.length=unit(0.5,'cm'))+scale_fill_igv()+
  geom_text(aes(label=signif(proportion, 4), y=proportion+0.005), position=position_dodge(1), vjust=0)

############### P1  #########
setwd("C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\repeat2\\P1")
P1<-readRDS('P1.cca')

new.cluster.ids_3 <- c("M.KO","L.KO","L.KO","unknown","unknown","ISC_IdC","unknown","unknown","unknown","HC",
                       "DC_OPC","unknown","CC_OSC_HeC","IPhc","unknown","unknown","OC90","unknown","unknown","HC","IPC","unknown","unknown","unknown")
names(new.cluster.ids_3) <- levels(P1)
P1 <- RenameIdents(P1, new.cluster.ids_3)

DimPlot(P1, reduction = "umap", label = TRUE, pt.size = 0.5,label.size = 6) + NoLegend()
VlnPlot(P1, features = c("Camk2n1","Chst2","Cxcl14","Gm10638","Hmga2","Kctd8","Lrrc10b","Paqr9","Pou4f3","S100a1","S100a13","Syt1","Xist"), 
        pt.size = 0, ncol =5, assay = "RNA",slot = "counts",log = T)+NoLegend()
FeaturePlot(P1, features = c("Camk2n1","Chst2","Cxcl14","Gm10638","Hmga2","Kctd8","Lrrc10b","Paqr9","Pou4f3","S100a1","S100a13","Syt1","Xist"),
            pt.size =  0.05, ncol = 5)
#
table(Idents(P1))
prop.table(table(Idents(P1)))
cell.prop_P1<-as.data.frame(prop.table(table(Idents(P1))))
#cell.prop_P1<-as.data.frame(table(Idents(P1)))
colnames(cell.prop_P1)<-c("cell_type","proportion")
cell.prop_P1$time<-"P1"
signif(cell.prop_P1$proportion, 4)

ggplot(cell.prop_P1,aes(cell_type,proportion,fill=cell_type))+geom_bar(stat="identity",position = position_dodge(1))+
  ggtitle("")+theme_bw()+theme(axis.ticks.length=unit(0.5,'cm'))+scale_fill_igv()+
  geom_text(aes(label=signif(proportion, 4), y=proportion+0.005), position=position_dodge(1), vjust=0)

############ P7
setwd("C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\repeat2\\P7")
P7<-readRDS('P7_cca')

new.cluster.ids_3 <- c("L.KO","unknown","unknown","M.KO","unknown","unknown","IPhC","CC_OS","HeC_Glia",
                       "OPC_IPC_DC","HC","unknown","L.KO","HC","unknown")
names(new.cluster.ids_3) <- levels(P7)
P7 <- RenameIdents(P7, new.cluster.ids_3)

DimPlot(P7, reduction = "umap", label = TRUE, pt.size = 0.5,label.size = 6) + NoLegend()
VlnPlot(P7, features = c("Camk2n1","Chst2","Cxcl14","Gm10638","Hmga2","Kctd8","Lrrc10b","Paqr9","Pou4f3","S100a1","S100a13","Syt1","Xist"), 
        pt.size = 0, ncol =5, assay = "RNA",slot = "counts",log = T)+NoLegend()
FeaturePlot(P7, features = c("Camk2n1","Chst2","Cxcl14","Gm10638","Hmga2","Kctd8","Lrrc10b","Paqr9","Pou4f3","S100a1","S100a13","Syt1","Xist"),
            pt.size =  0.05, ncol = 5)
#
table(Idents(P7))
#prop.table(table(Idents(P7)))
cell.prop_P7<-as.data.frame(prop.table(table(Idents(P7))))
#cell.prop_P7<-as.data.frame(table(Idents(P7)))
colnames(cell.prop_P7)<-c("cell_type","proportion")
cell.prop_P7$time<-"P7"
signif(cell.prop_P7$proportion, 4)

ggplot(cell.prop_P7,aes(cell_type,proportion,fill=cell_type))+geom_bar(stat="identity",position = position_dodge(1))+
  ggtitle("")+theme_bw()+theme(axis.ticks.length=unit(0.5,'cm'))+scale_fill_igv()+
  geom_text(aes(label=signif(proportion, 4), y=proportion+0.005), position=position_dodge(1), vjust=0)
      
######### merge
merge<- rbind(cell.prop_E14,cell.prop_E16,cell.prop_P1,cell.prop_P7)

ggplot(merge,aes(time,proportion,fill=cell_type))+geom_bar(stat='identity',position='stack')+
  ggtitle("")+theme_bw()+theme(axis.ticks.length=unit(0.5,'cm'))+scale_fill_igv()



setwd("C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\repeat2\\sc_RNA_edgeR")
merge_r1 <- data.frame(cell_type=NA,proportion=NA,time=NA)
merge_r1<- merge_r1[-1,]
for(i in 1:length(unique(merge$cell_type))){
  merge_w <- merge[merge$cell_type%in%merge$cell_type[i],]
  merge_r2 <- data.frame(cell_type=NA,proportion=NA,time=NA)
  merge_r2<- merge_r2[-1,]
  for (j in 1:length(unique(merge_w$time))){
    merge_w2<- merge_w[merge_w$time%in%merge_w$time[j],]
    merge_w3<-data.frame("other cell type",(1-merge_w2$proportion),merge_w2$time)
    colnames(merge_w3)<-c(colnames(merge_w2))
    merge_w4 <- rbind(merge_w2,merge_w3)
    merge_r2<- rbind(merge_r2,merge_w4)
}
  merge_r1<- rbind(merge_r1,merge_r2)
  p<-ggplot(merge_r2,aes(time,proportion,fill=cell_type))+geom_bar(stat='identity',position='stack')+
    ggtitle("")+theme_bw()+theme(axis.ticks.length=unit(0.5,'cm'))+scale_fill_manual(values=c("#003399","#9999CC"))
  file_name<-paste("proportion_",merge$cell_type[i],".pdf",sep = "")
  ggsave(p,file=file_name,width = 5,height = 4,device = "pdf")

}

P







































































































































































































































































































































































































































































































































































































































































































































































































































































































































































