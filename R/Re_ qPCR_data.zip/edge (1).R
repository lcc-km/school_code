library(Seurat)
library(dplyr)
library(magrittr)
library(ggplot2)
setwd("C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\重复repeat\\sc_RNA_edgeR")

P12_1 <- Read10X(data.dir ="P12_1")
seurat_P12_1 <- CreateSeuratObject(counts = P12_1)
write.table(seurat_P12_1@assays$RNA@counts, "count_P12_1.txt",sep="\t", quote=F, col.names=NA)

count_P12_1_work <- read.csv("count_P12_1.txt",sep = "\t",row.names = 1)
count_P12_1_work$sun<-rowSums(count_P12_1_work)
done_P12_1<-data.frame(gene=row.names(count_P12_1_work),count_P12_1_work$sun)

P12_2 <- Read10X(data.dir ="P12_2")
seurat_P12_2 <- CreateSeuratObject(counts = P12_2)
write.table(seurat_P12_2@assays$RNA@counts, "count_P12_2.txt",sep="\t", quote=F, col.names=NA)

count_P12_2_work <- read.csv("count_P12_2.txt",sep = "\t",row.names = 1)
count_P12_2_work$sun<-rowSums(count_P12_2_work)
done_P12_2<-data.frame(gene=row.names(count_P12_2_work),count_P12_2_work$sun)


P33 <- Read10X(data.dir ="P33")
seurat_P33 <- CreateSeuratObject(counts = P33)
write.table(seurat_P33@assays$RNA@counts, "count_P33.txt",sep="\t", quote=F, col.names=NA)

count_P33_work <- read.csv("count_P33.txt",sep = "\t",row.names = 1)
count_P33_work$sun<-rowSums(count_P33_work)
done_P33<-data.frame(gene=row.names(count_P33_work),count_P33_work$sun)

#######  4
E14_2 <- Read10X(data.dir = "C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\E14\\E14_2")

E16_1 <- Read10X(data.dir = "D:\\E16\\E16_1")
E16_2 <- Read10X(data.dir = "D:\\E16\\E16_2")
E16_3 <- Read10X(data.dir = "D:\\E16\\E16_3")

P1_1 <- Read10X(data.dir = "C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\重复repeat\\P1\\1")
P1_2 <- Read10X(data.dir = "C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\重复repeat\\P1\\2")
P1_3 <- Read10X(data.dir = "C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\重复repeat\\P1\\3")
P1_4 <- Read10X(data.dir = "C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\重复repeat\\P1\\4")

P7_1 <- Read10X(data.dir = "C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\重复repeat\\P7\\1")
P7_2 <- Read10X(data.dir = "C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\重复repeat\\P7\\2")

seurat_E14_2 <- CreateSeuratObject(counts = E14_2)
seurat_E16_1 <- CreateSeuratObject(counts = E16_1)
seurat_E16_2 <- CreateSeuratObject(counts = E16_2)
seurat_E16_3 <- CreateSeuratObject(counts = E16_3)
seurat_P1_1 <- CreateSeuratObject(counts = P1_1)
seurat_P1_2 <- CreateSeuratObject(counts = P1_2)
seurat_P1_3 <- CreateSeuratObject(counts = P1_3)
seurat_P1_4 <- CreateSeuratObject(counts = P1_4)
seurat_P7_1 <- CreateSeuratObject(counts = P7_1)
seurat_P7_2 <- CreateSeuratObject(counts = P7_2)


write.table(seurat_E14_2@assays$RNA@counts, "count_E14_2.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_E16_1@assays$RNA@counts, "count_E16_1.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_E16_2@assays$RNA@counts, "count_E16_2.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_E16_3@assays$RNA@counts, "count_E16_3.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_P1_1@assays$RNA@counts, "count_P1_1.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_P1_2@assays$RNA@counts, "count_P1_2.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_P1_3@assays$RNA@counts, "count_P1_3.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_P1_4@assays$RNA@counts, "count_P1_4.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_P7_1@assays$RNA@counts, "count_P7_1.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_P7_2@assays$RNA@counts, "count_P7_2.txt",sep="\t", quote=F, col.names=NA)


count_P12_1_work <- read.csv("count_P12_1.txt",sep = "\t",row.names = 1)
count_P12_1_work$sun<-rowSums(count_P12_1_work)
done_P12_1<-data.frame(gene=row.names(count_P12_1_work),count_P12_1_work$sun)

count_P12_2_work <- read.csv("count_P12_2.txt",sep = "\t",row.names = 1)
count_P12_2_work$sun<-rowSums(count_P12_2_work)
done_P12_2<-data.frame(gene=row.names(count_P12_2_work),count_P12_2_work$sun)

count_P33_work <- read.csv("count_P33.txt",sep = "\t",row.names = 1)
count_P33_work$sun<-rowSums(count_P33_work)
done_P33<-data.frame(gene=row.names(count_P33_work),count_P33_work$sun)

count_E14_2_work <- read.csv("count_E14_2.txt",sep = "\t",row.names = 1)
count_E14_2_work$sun<-rowSums(count_E14_2_work)
done_E14_2<-data.frame(gene=row.names(count_E14_2_work),count_E14_2_work$sun)

count_E16_1_work <- read.csv("count_E16_1.txt",sep = "\t",row.names = 1)
count_E16_1_work$sun<-rowSums(count_E16_1_work)
done_E16_1<-data.frame(gene=row.names(count_E16_1_work),count_E16_1_work$sun)

count_E16_2_work <- read.csv("count_E16_2.txt",sep = "\t",row.names = 1)
count_E16_2_work$sun<-rowSums(count_E16_2_work)
done_E16_2<-data.frame(gene=row.names(count_E16_2_work),count_E16_2_work$sun)

count_E16_3_work <- read.csv("count_E16_3.txt",sep = "\t",row.names = 1)
count_E16_3_work$sun<-rowSums(count_E16_3_work)
done_E16_3<-data.frame(gene=row.names(count_E16_3_work),count_E16_3_work$sun)

count_P1_1_work <- read.csv("count_P1_1.txt",sep = "\t",row.names = 1)
count_P1_1_work$sun<-rowSums(count_P1_1_work)
done_P1_1<-data.frame(gene=row.names(count_P1_1_work),count_P1_1_work$sun)

count_P1_2_work <- read.csv("count_P1_2.txt",sep = "\t",row.names = 1)
count_P1_2_work$sun<-rowSums(count_P1_2_work)
done_P1_2<-data.frame(gene=row.names(count_P1_2_work),count_P1_2_work$sun)

count_P1_3_work <- read.csv("count_P1_3.txt",sep = "\t",row.names = 1)
count_P1_3_work$sun<-rowSums(count_P1_3_work)
done_P1_3<-data.frame(gene=row.names(count_P1_3_work),count_P1_3_work$sun)

count_P1_4_work <- read.csv("count_P1_4.txt",sep = "\t",row.names = 1)
count_P1_4_work$sun<-rowSums(count_P1_4_work)
done_P1_4<-data.frame(gene=row.names(count_P1_2_work),count_P1_4_work$sun)

count_P7_1_work <- read.csv("count_P7_1.txt",sep = "\t",row.names = 1)
count_P7_1_work$sun<-rowSums(count_P7_1_work)
done_P7_1<-data.frame(gene=row.names(count_P7_1_work),count_P7_1_work$sun)

count_P7_2_work <- read.csv("count_P7_2.txt",sep = "\t",row.names = 1)
count_P7_2_work$sun<-rowSums(count_P7_2_work)
done_P7_2<-data.frame(gene=row.names(count_P7_2_work),count_P7_2_work$sun)




merge1<-merge(done_P12_1,done_P12_2,by.x="gene")
merge2 <-merge(merge1,done_P33,by.x="gene")

merge3 <-merge(merge2,done_E14_2,by.x="gene")

merge4 <-merge(merge3,done_E16_1,by.x="gene")
merge5 <-merge(merge4,done_E16_2,by.x="gene")
merge6 <-merge(merge5,done_E16_3,by.x="gene")
merge7 <-merge(merge6,done_P1_1,by.x="gene")
merge8 <-merge(merge7,done_P1_2,by.x="gene")

merge9 <-merge(merge8,done_P1_3,by.x="gene")

merge10 <-merge(merge9,done_P1_4,by.x="gene")
merge11 <-merge(merge10,done_P7_1,by.x="gene")

all_merge<-merge(merge11,done_P7_2,by.x="gene")

write.table(all_merge,"all_merge.txt",sep="\t", quote=F,row.names = F)



###
library(edgeR)

spe <- "cochlear_"   ## 设置比较的物种

data <-  read.csv("all_merge.txt", header=T, sep = "\t",row.names=1)

###设置分组

targets <- data.frame(seq=c(1:13),
                      control=c("P12","P12","P33","E14","E16","E16","E16",
                                "P1","P1","P1","P1","P7","P7"),
                      Label=c("P12_1","P12_2","P33","E14_2","E16_1","E16_2",
                              "E16_3","P1_1","P1_2","P1_3","P1_4","P7_1","P7_2"))  
############ 计算表达差异 gene ##########################
###  normalize by TMM and save data to exp_study

y = DGEList(counts=data, group=targets$control)          

y = calcNormFactors(y,method = "TMM") #get TMM nomalization factor # 计算样本内标准化因子
y$samples
y
colnames(y) <- targets$Label   ###6个样完整时用
dim(y)
###  PCA analysis , 评估样品整体表达模式之间的相似程度

pp<-plotMDS(y,method="bcv")

###  estimating the dispersion  or  Estimating dispersion
y1 <- y #get data
BVC=0.1 ##?????
y1$common.dispersion=BVC
y1 = estimateTagwiseDisp(y1)  #计算普通的离散度
y1 
plotBCV(y1)

## opt 1: partly compare
t <- list()
conditions <- factor(unique(targets$control))
conditions
for(i in 1:length(conditions)){
  t[[i]] <- c(as.character(conditions[i]),as.character(conditions[3]))
}





thrd <- 0.05
chg_rd=1
for(i in 1:length(t)){
  ###  get paires #,  UbR;2=S&8y>]PhR*8|8D#!#!
  test <- t[[i]] ##get names of test pairs
  comp <- paste(test[2],test[1],sep = "-")   ## W"Rb!!1H6T=a9{N* test[2]-test[1]
  comp
  
  ###   exactTest & write file
  et0 <- exactTest(y1,pair = test)
  topTags(et0)
  et0.d <-data.frame(topTags(et0,n=nrow(et0$table)))
  filename1 <- paste(spe,comp,"_all_exact_FC.txt",sep ="")
  write.table(et0.d,filename1,quote=F,sep = "\t")
  
  
  # drawing DE gene plot (optioinal)
  de <- decideTestsDGE(et0,p=thrd,lfc = chg_rd)
  summary(de) ##get number of different exp gene, -1 down regulate#,1 up regulate, 0 no difference
  plotSmear(et0,de.tags = rownames(y1)[as.logical(de)])
  abline(h=c(0-chg_rd,chg_rd),col="blue")
  
  filename <- paste(spe,comp,"_exact_FC",chg_rd,"_FDR",thrd,".pdf",sep ="")
  pdf(file = filename,width = 5,height = 5,title = comp)
  plotSmear(et0,de.tags = rownames(y1)[as.logical(de)])
  abline(h=c(0-chg_rd,chg_rd),col="blue")
  title(paste(spe,comp))
  dev.off()
  
  
  #get DE gene text file
  data0 <- et0.d[abs(et0.d[,"logFC"])>chg_rd & et0.d[,"FDR"]<thrd,]
  filename <- paste(spe,comp,"_exact_FC",chg_rd,"_FDR",thrd,".txt",sep ="")
  write.table(data0,filename,quote=F,sep = "\t")
  
}

#########
library(venn)
library(dplyr)
FC_E14_E16 <- read.csv("cochlear_E14-E16_exact_FC1_FDR0.05.txt",sep = "\t")
FC_E14_E16$gene <- row.names(FC_E14_E16)

FC_E14_P1 <- read.csv("cochlear_E14-P1_exact_FC1_FDR0.05.txt",sep = "\t")
FC_E14_P1$gene <- row.names(FC_E14_P1)

FC_E14_P7 <- read.csv("cochlear_E14-P7_exact_FC1_FDR0.05.txt",sep = "\t")
FC_E14_P7$gene <- row.names(FC_E14_P7)

FC_E14_P12 <- read.csv("cochlear_E14-P12_exact_FC1_FDR0.05.txt",sep = "\t")
FC_E14_P12$gene <- row.names(FC_E14_P12)

FC_E14_P33 <- read.csv("cochlear_E14-P33_exact_FC1_FDR0.05.txt",sep = "\t")
FC_E14_P33$gene <- row.names(FC_E14_P33)

data_venn <- list(E16=FC_E14_E16$gene,
                  P1=FC_E14_P1$gene,
                  P7=FC_E14_P7$gene)

venn(data_venn,zcolor='style')

venn_list <- Reduce(intersect,data_venn)

FC_E14_E16_venn <- FC_E14_E16[FC_E14_E16$gene%in%venn_list,c(1,5)]
FC_E14_P1_venn <- FC_E14_P1[FC_E14_P1$gene%in%venn_list,c(1,5)]
FC_E14_P7_venn <- FC_E14_P7[FC_E14_P7$gene%in%venn_list,c(1,5)]
FC_E14_P12_venn <- FC_E14_P12[FC_E14_P12$gene%in%venn_list,c(1,5)]
FC_E14_P33_venn <- FC_E14_P33[FC_E14_P33$gene%in%venn_list,c(1,5)]

merge11<-merge(FC_E14_E16_venn,FC_E14_P1_venn,by = "gene",all = T)
colnames(merge11)<-c("gene","E14_E16","E14_P1")

merge22<-merge(merge11,FC_E14_P7_venn,by = "gene",all = T)
colnames(merge22)<-c("gene","E14_E16","E14_P1","E14_P7")

merge33<-merge(merge22,FC_E14_P12_venn,by = "gene",all = T)
colnames(merge33)<-c("gene","E14_E16","E14_P1","E14_P7","E14_P12")


all_FC_merge<-merge(merge33,FC_E14_P33_venn,by = "gene",all = T)
colnames(all_FC_merge)<-c("gene","E14_E16","E14_P1","E14_P7","E14_P12","E14_P33")

write.table(all_FC_merge,"all_FC_merge",quote=F,sep = "\t")
