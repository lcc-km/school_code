library(Seurat)
library(dplyr)
library(magrittr)
library(ggplot2)


#############################################################################################################
###############Find different genes at different times from single cell datasets in mouse cochlear ##########
############################################################################################################


#############data early treatment#################
########read three original files#########
setwd("C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\repeat2\\sc_RNA_edgeR")


########create seurat objects of different times #########
E14<- Read10X(data.dir = "E14")
seurat_E14 <- CreateSeuratObject(counts = E14, project = "E14", min.cells = 3, min.features = 200)
seurat_E14[["percent.mt"]] <- PercentageFeatureSet(seurat_E14, pattern = "^mt-")
VlnPlot(seurat_E14, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
plot1 <- FeatureScatter(seurat_E14, feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(seurat_E14, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot1
plot2
seurat_E14<- subset(seurat_E14, subset = nFeature_RNA > 200 & nFeature_RNA < 4500 & percent.mt < 5)



E16_1 <- Read10X(data.dir = "E16_1")
seurat_E16_1 <- CreateSeuratObject(counts = E16_1, project = "E16_1", min.cells = 3, min.features = 200)
seurat_E16_1 [["percent.mt"]] <- PercentageFeatureSet(seurat_E16_1 , pattern = "^mt-")
VlnPlot(seurat_E16_1 , features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
plot1 <- FeatureScatter(seurat_E16_1 , feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(seurat_E16_1 , feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot1
plot2
seurat_E16_1 <- subset(seurat_E16_1 , subset = nFeature_RNA > 200 & nFeature_RNA < 2000 & percent.mt < 8)



E16_2 <- Read10X(data.dir = "E16_2")
seurat_E16_2 <- CreateSeuratObject(counts = E16_2, project = "E16_2", min.cells = 3, min.features = 200)
seurat_E16_2 [["percent.mt"]] <- PercentageFeatureSet(seurat_E16_2 , pattern = "^mt-")
VlnPlot(seurat_E16_2 , features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
plot1 <- FeatureScatter(seurat_E16_2 , feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(seurat_E16_2 , feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot1
plot2
seurat_E16_2 <- subset(seurat_E16_2 , subset = nFeature_RNA > 200 & nFeature_RNA < 3000 & percent.mt < 8)


E16_3 <- Read10X(data.dir = "E16_3")
seurat_E16_3 <- CreateSeuratObject(counts = E16_3, project = "E16_3", min.cells = 3, min.features = 200)
seurat_E16_3 [["percent.mt"]] <- PercentageFeatureSet(seurat_E16_3 , pattern = "^mt-")
VlnPlot(seurat_E16_3 , features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
plot1 <- FeatureScatter(seurat_E16_3 , feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(seurat_E16_3 , feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot1
plot2
seurat_E16_3<- subset(seurat_E16_3 , subset = nFeature_RNA > 200 & nFeature_RNA < 2500 & percent.mt < 8)


P1_1 <- Read10X(data.dir = "p1_1")
seurat_P1_1 <- CreateSeuratObject(counts = P1_1, project = "P1_1", min.cells = 3, min.features = 200)
seurat_P1_1 [["percent.mt"]] <- PercentageFeatureSet(seurat_P1_1 , pattern = "^mt-")
VlnPlot(seurat_P1_1 , features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
plot1 <- FeatureScatter(seurat_P1_1, feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(seurat_P1_1 , feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot1
plot2
seurat_P1_1<- subset(seurat_P1_1 , subset = nFeature_RNA > 200 & nFeature_RNA < 4500 & percent.mt < 8)


P1_2 <- Read10X(data.dir = "p1_2")
seurat_P1_2 <- CreateSeuratObject(counts = P1_2, project = "P1_2", min.cells = 3, min.features = 200)
seurat_P1_2 [["percent.mt"]] <- PercentageFeatureSet(seurat_P1_2 , pattern = "^mt-")
VlnPlot(seurat_P1_2 , features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
plot1 <- FeatureScatter(seurat_P1_2, feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(seurat_P1_2, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot1
plot2
seurat_P1_2<- subset(seurat_P1_2 , subset = nFeature_RNA > 200 & nFeature_RNA < 3500 & percent.mt < 5)


P1_3 <- Read10X(data.dir = "p1_3")
seurat_P1_3 <- CreateSeuratObject(counts = P1_3, project = "P1_3", min.cells = 3, min.features = 200)
seurat_P1_3 [["percent.mt"]] <- PercentageFeatureSet(seurat_P1_3 , pattern = "^mt-")
VlnPlot(seurat_P1_3 , features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
plot1 <- FeatureScatter(seurat_P1_3, feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(seurat_P1_3, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot1
plot2
seurat_P1_3<- subset(seurat_P1_3, subset = nFeature_RNA > 200 & nFeature_RNA < 3500 & percent.mt < 5)


P1_4 <- Read10X(data.dir = "p1_4")
seurat_P1_4 <- CreateSeuratObject(counts = P1_4, project = "P1_4", min.cells = 3, min.features = 200)
seurat_P1_4 [["percent.mt"]] <- PercentageFeatureSet(seurat_P1_4 , pattern = "^mt-")
VlnPlot(seurat_P1_4 , features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
plot1 <- FeatureScatter(seurat_P1_4, feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(seurat_P1_4, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot1
plot2
seurat_P1_4<- subset(seurat_P1_4, subset = nFeature_RNA > 200 & nFeature_RNA < 3500 & percent.mt < 8)


P7_1 <- Read10X(data.dir = "p7_1")
seurat_P7_1 <- CreateSeuratObject(counts = P7_1, project = "P7_1", min.cells = 3, min.features = 200)
seurat_P7_1 [["percent.mt"]] <- PercentageFeatureSet(seurat_P7_1 , pattern = "^mt-")
VlnPlot(seurat_P7_1 , features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
plot1 <- FeatureScatter(seurat_P7_1, feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(seurat_P7_1, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot1
plot2
seurat_P7_1<- subset(seurat_P7_1, subset = nFeature_RNA > 200 & nFeature_RNA < 3500 & percent.mt < 5)


P7_2 <- Read10X(data.dir = "p7_2")
seurat_P7_2 <- CreateSeuratObject(counts = P7_2, project = "P7_2", min.cells = 3, min.features = 200)
seurat_P7_2 [["percent.mt"]] <- PercentageFeatureSet(seurat_P7_2 , pattern = "^mt-")
VlnPlot(seurat_P7_2 , features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
plot1 <- FeatureScatter(seurat_P7_2, feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(seurat_P7_2, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot1
plot2
seurat_P7_2<- subset(seurat_P7_2, subset = nFeature_RNA > 200 & nFeature_RNA < 3500 & percent.mt < 5)


P12_1 <- Read10X(data.dir ="P12_1")
seurat_P12_1 <- CreateSeuratObject(counts = P12_1, project = "P12_1", min.cells = 3, min.features = 200)
seurat_P12_1[["percent.mt"]] <- PercentageFeatureSet(seurat_P12_1 , pattern = "^mt-")
VlnPlot(seurat_P12_1 , features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
plot1 <- FeatureScatter(seurat_P12_1, feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(seurat_P12_1, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot1
plot2
seurat_P12_1<- subset(seurat_P12_1, subset = nFeature_RNA > 200 & nFeature_RNA < 5000 & percent.mt < 10)



P12_2 <- Read10X(data.dir ="P12_2")
seurat_P12_2 <- CreateSeuratObject(counts = P12_2, project = "P12_2", min.cells = 3, min.features = 200)
seurat_P12_2[["percent.mt"]] <- PercentageFeatureSet(seurat_P12_2 , pattern = "^mt-")
VlnPlot(seurat_P12_2 , features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
plot1 <- FeatureScatter(seurat_P12_2, feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(seurat_P12_2, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot1
plot2
seurat_P12_2<- subset(seurat_P12_2, subset = nFeature_RNA > 200 & nFeature_RNA < 5000 & percent.mt < 10)


P33 <- Read10X(data.dir ="P33")
seurat_P33 <- CreateSeuratObject(counts = P33, project = "P33", min.cells = 3, min.features = 200)
seurat_P33[["percent.mt"]] <- PercentageFeatureSet(seurat_P33 , pattern = "^mt-")
VlnPlot(seurat_P33 , features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
plot1 <- FeatureScatter(seurat_P33, feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(seurat_P33, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot1
plot2
seurat_P33<- subset(seurat_P33, subset = nFeature_RNA > 200 & nFeature_RNA < 5000 & percent.mt < 10)




########export expression matrix of different times #########

write.table(seurat_E14@assays$RNA@counts, "E14_matrix.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_E16_1@assays$RNA@counts, "E16_1_matrix.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_E16_2@assays$RNA@counts, "E16_2_matrix.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_E16_3@assays$RNA@counts, "E16_3_matrix.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_P1_1@assays$RNA@counts, "P1_1_matrix.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_P1_2@assays$RNA@counts, "P1_2_matrix.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_P1_3@assays$RNA@counts, "P1_3_matrix.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_P1_4@assays$RNA@counts, "P1_4_matrix.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_P7_1@assays$RNA@counts, "P7_1_matrix.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_P7_2@assays$RNA@counts, "P7_2_matrix.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_P12_1@assays$RNA@counts, "P12_1_matrix.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_P12_2@assays$RNA@counts, "P12_2_matrix.txt",sep="\t", quote=F, col.names=NA)
write.table(seurat_P33@assays$RNA@counts, "P33_matrix.txt",sep="\t", quote=F, col.names=NA)

############ Add  all the counts for each gene and export in respective matrix ##########
count_E14_work <- read.csv("E14_matrix.txt",sep = "\t",row.names = 1)
count_E14_work$sun<-rowSums(count_E14_work) ######## add gene counts of each gene
done_E14<-data.frame(gene=row.names(count_E14_work),count_E14_work$sun)####create a dataframe
write.table(done_E14, "E14_add_matrix.txt",sep="\t", quote=F)

count_E16_1_work <- read.csv("E16_1_matrix.txt",sep = "\t",row.names = 1)
count_E16_1_work$sun<-rowSums(count_E16_1_work)
done_E16_1<-data.frame(gene=row.names(count_E16_1_work),count_E16_1_work$sun)
write.table(done_E16_1, "E16_1_add_matrix.txt",sep="\t", quote=F)


count_E16_2_work <- read.csv("E16_2_matrix.txt",sep = "\t",row.names = 1)
count_E16_2_work$sun<-rowSums(count_E16_2_work)
done_E16_2<-data.frame(gene=row.names(count_E16_2_work),count_E16_2_work$sun)
write.table(done_E16_2, "E16_2_add_matrix.txt",sep="\t", quote=F)

count_E16_3_work <- read.csv("E16_3_matrix.txt",sep = "\t",row.names = 1)
count_E16_3_work$sun<-rowSums(count_E16_3_work)
done_E16_3<-data.frame(gene=row.names(count_E16_3_work),count_E16_3_work$sun)
write.table(done_E16_3, "E16_3_add_matrix.txt",sep="\t", quote=F)

count_P1_1_work <- read.csv("P1_1_matrix.txt",sep = "\t",row.names = 1)
count_P1_1_work$sun<-rowSums(count_P1_1_work)
done_P1_1<-data.frame(gene=row.names(count_P1_1_work),count_P1_1_work$sun)
write.table(done_P1_1, "P1_1_add_matrix.txt",sep="\t", quote=F)

count_P1_2_work <- read.csv("P1_2_matrix.txt",sep = "\t",row.names = 1)
count_P1_2_work$sun<-rowSums(count_P1_2_work)
done_P1_2<-data.frame(gene=row.names(count_P1_2_work),count_P1_2_work$sun)
write.table(done_P1_2, "P1_2_add_matrix.txt",sep="\t", quote=F)

count_P1_3_work <- read.csv("P1_3_matrix.txt",sep = "\t",row.names = 1)
count_P1_3_work$sun<-rowSums(count_P1_3_work)
done_P1_3<-data.frame(gene=row.names(count_P1_3_work),count_P1_3_work$sun)
write.table(done_P1_3, "P1_3_add_matrix.txt",sep="\t", quote=F)

count_P1_4_work <- read.csv("P1_4_matrix.txt",sep = "\t",row.names = 1)
count_P1_4_work$sun<-rowSums(count_P1_4_work)
done_P1_4<-data.frame(gene=row.names(count_P1_4_work),count_P1_4_work$sun)
write.table(done_P1_4, "P1_4_add_matrix.txt",sep="\t", quote=F)


count_P7_1_work <- read.csv("P7_1_matrix.txt",sep = "\t",row.names = 1)
count_P7_1_work$sun<-rowSums(count_P7_1_work)
done_P7_1<-data.frame(gene=row.names(count_P7_1_work),count_P7_1_work$sun)
write.table(done_P7_1, "P7_1_add_matrix.txt",sep="\t", quote=F)

count_P7_2_work <- read.csv("P7_2_matrix.txt",sep = "\t",row.names = 1)
count_P7_2_work$sun<-rowSums(count_P7_2_work)
done_P7_2<-data.frame(gene=row.names(count_P7_2_work),count_P7_2_work$sun)
write.table(done_P7_2, "P7_2_add_matrix.txt",sep="\t", quote=F)


count_P12_1_work <- read.csv("P12_1_matrix.txt",sep = "\t",row.names = 1)
count_P12_1_work$sun<-rowSums(count_P12_1_work)
done_P12_1<-data.frame(gene=row.names(count_P12_1_work),count_P12_1_work$sun)
write.table(done_P12_1, "P12_1_add_matrix.txt",sep="\t", quote=F)


count_P12_2_work <- read.csv("P12_2_matrix.txt",sep = "\t",row.names = 1)
count_P12_2_work$sun<-rowSums(count_P12_2_work)
done_P12_2<-data.frame(gene=row.names(count_P12_2_work),count_P12_2_work$sun)
write.table(done_P12_2, "P12_2_add_matrix.txt",sep="\t", quote=F)

count_P33_work <- read.csv("P33_matrix.txt",sep = "\t",row.names = 1)
count_P33_work$sun<-rowSums(count_P33_work)
done_P33<-data.frame(gene=row.names(count_P33_work),count_P33_work$sun)
write.table(done_P33, "P33_add_matrix.txt",sep="\t", quote=F)

################ merge all times by genes in one matrix ############
merge1<-merge(done_E14,done_E16_1,by.x="gene")
merge2 <-merge(merge1,done_E16_2,by.x="gene")
merge3 <-merge(merge2,done_E16_3,by.x="gene")
merge4 <-merge(merge3,done_P1_1,by.x="gene")
merge5 <-merge(merge4,done_P1_2,by.x="gene")
merge6 <-merge(merge5,done_P1_3,by.x="gene")
merge7 <-merge(merge6,done_P1_4,by.x="gene")
merge8 <-merge(merge7,done_P7_1,by.x="gene")
merge9 <-merge(merge8,done_P7_2,by.x="gene")
merge10 <-merge(merge9,done_P12_1,by.x="gene")
merge11 <-merge(merge10,done_P12_2,by.x="gene")
all_merge<-merge(merge11,done_P33,by.x="gene")

write.table(all_merge,"all_merge.txt",sep="\t", quote=F,row.names = F)
